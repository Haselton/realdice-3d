# Frost Line: Shasta — Android APK Demo

Playable vertical-slice prototype for Android.

## Demo features
- Landscape downhill snowboarding run
- Phone motion carving and pitch-based speed control
- Accelerometer flick-to-jump
- On-screen Jump, Grind, and Camera Reset buttons
- Calibration flow
- Mount Shasta-inspired summit silhouette and snowfield descent
- Procedural trees, rocks, ice, crevasses
- Bear, cougar, and yeti encounters
- Frost Byte-inspired launch colors/outfit silhouette
- Score, crashes, near misses, progress, finish state

This is a gameplay prototype. Final production will replace the procedural 2.5D demo rendering with Blender-derived 3D hero, terrain, creatures, and baked assets from the approved production package.
