package com.haseltonmediagroup.frostline;

import android.content.Context;
import android.graphics.*;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class FrostGameView extends View implements SensorEventListener {
    public interface Haptic { void pulse(); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Haptic haptic;
    private final Random rng = new Random(417122193L);
    private final ArrayList<Hazard> hazards = new ArrayList<>();
    private final float[] rot = new float[9];
    private final float[] ori = new float[3];

    private long lastNanos = 0L;
    private boolean paused = false;
    private boolean calibrated = false;
    private boolean finished = false;
    private float neutralRoll = 0f, neutralPitch = 0f;
    private float steer = 0f, stance = 0f;
    private float playerX = 0f;
    private float speed = 25f;
    private float distance = 0f;
    private float jumpY = 0f, jumpV = 0f;
    private float grindFlash = 0f;
    private float lastAccelMag = 9.81f;
    private long lastFlickMs = 0;
    private int crashes = 0;
    private int score = 0;
    private int nearMisses = 0;

    private RectF jumpBtn = new RectF();
    private RectF grindBtn = new RectF();
    private RectF resetBtn = new RectF();

    private static final float RUN_LENGTH = 2200f;
    private static final float VIEW_DIST = 180f;

    private static class Hazard {
        float x, z;
        int type; // 0 tree,1 rock,2 ice,3 crevasse,4 bear,5 cougar,6 yeti
        boolean hit;
        Hazard(float x,float z,int type){this.x=x;this.z=z;this.type=type;}
    }

    public FrostGameView(Context context, Haptic haptic) {
        super(context);
        this.haptic = haptic;
        p.setTypeface(Typeface.create("sans", Typeface.BOLD));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        setFocusable(true);
        seedHazards();
    }

    private void seedHazards() {
        hazards.clear();
        float z = 90f;
        while (z < RUN_LENGTH + VIEW_DIST) {
            z += 35f + rng.nextFloat()*36f;
            int type;
            float t = z / RUN_LENGTH;
            if (z > 450 && rng.nextFloat() < .09f) type = 4; // bear
            else if (z > 900 && rng.nextFloat() < .09f) type = 5; // cougar
            else if (z > 1500 && rng.nextFloat() < .06f) type = 6; // yeti
            else {
                float r = rng.nextFloat();
                type = r < .38 ? 0 : r < .62 ? 1 : r < .80 ? 2 : 3;
            }
            float width = 8.5f - Math.min(2.0f, t*2f);
            hazards.add(new Hazard((rng.nextFloat()*2f-1f)*width, z, type));
            if (rng.nextFloat() < .28f) {
                int type2 = rng.nextBoolean() ? 0 : 1;
                hazards.add(new Hazard((rng.nextFloat()*2f-1f)*width, z+rng.nextFloat()*12f, type2));
            }
        }
    }

    public void resumeGame(){ paused=false; lastNanos=0; invalidate(); }
    public void pauseGame(){ paused=true; }

    private void calibrate() {
        neutralRoll += 0; // baseline values are set from next rotation event
        calibrated = false;
        haptic.pulse();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (e.sensor.getType() == Sensor.TYPE_GAME_ROTATION_VECTOR ||
            e.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            android.hardware.SensorManager.getRotationMatrixFromVector(rot, e.values);
            android.hardware.SensorManager.getOrientation(rot, ori);
            // Landscape mapping: roll is ori[1], pitch-like input is ori[2].
            float roll = ori[1];
            float pitch = ori[2];
            if (!calibrated) {
                neutralRoll = roll;
                neutralPitch = pitch;
                calibrated = true;
                haptic.pulse();
            }
            float rd = (float)Math.toDegrees(wrapAngle(roll-neutralRoll));
            float pd = (float)Math.toDegrees(wrapAngle(pitch-neutralPitch));
            steer = shaped(rd, 3f, 24f);
            stance = shaped(-pd, 3f, 18f);
        } else if (e.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x=e.values[0],y=e.values[1],z=e.values[2];
            float mag=(float)Math.sqrt(x*x+y*y+z*z);
            float impulse=Math.abs(mag-lastAccelMag);
            lastAccelMag = lastAccelMag*0.86f + mag*0.14f;
            long now=SystemClock.uptimeMillis();
            if (impulse > 5.2f && now-lastFlickMs > 520 && jumpY <= 0.01f) {
                lastFlickMs = now;
                jump();
            }
        }
    }

    private float wrapAngle(float a) {
        while(a > Math.PI) a -= (float)(Math.PI*2);
        while(a < -Math.PI) a += (float)(Math.PI*2);
        return a;
    }

    private float shaped(float v,float dead,float full){
        float a=Math.abs(v);
        if(a<=dead)return 0f;
        float t=Math.min(1f,(a-dead)/(full-dead));
        t=t*t*(3f-2f*t);
        return Math.signum(v)*t;
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void jump(){
        if(jumpY<=0.01f){
            jumpV=7.8f;
            haptic.pulse();
        }
    }

    private void restart(){
        distance=0; speed=25; playerX=0; jumpY=0; jumpV=0;
        crashes=0; score=0; nearMisses=0; finished=false;
        rng.setSeed(417122193L);
        seedHazards();
        calibrate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (paused) return;
        long now=System.nanoTime();
        float dt=lastNanos==0?0.016f:Math.min(.034f,(now-lastNanos)/1_000_000_000f);
        lastNanos=now;
        update(dt);
        drawWorld(c);
        postInvalidateOnAnimation();
    }

    private void update(float dt){
        if(finished) return;
        float target=stance>0 ? 29f+stance*16f : 29f+stance*11f;
        speed += (target-speed)*Math.min(1,dt*2.3f);
        speed=Math.max(10f,Math.min(46f,speed));
        playerX += steer * (5.0f + speed*.07f) * dt;
        playerX=Math.max(-9.5f,Math.min(9.5f,playerX));
        distance += speed*dt;
        score += (int)(speed*dt*1.2f);

        if(jumpY>0 || jumpV>0){
            jumpV -= 18.5f*dt;
            jumpY += jumpV*dt;
            if(jumpY<0){ jumpY=0; jumpV=0; haptic.pulse(); }
        }
        if(grindFlash>0) grindFlash -= dt;

        for(Hazard h:hazards){
            float rel=h.z-distance;
            if(!h.hit && rel<3.4f && rel>-2f){
                float dx=Math.abs(h.x-playerX);
                float hitRadius=(h.type==3?1.8f:(h.type>=4?1.55f:1.15f));
                if(dx<hitRadius && jumpY<1.15f && h.type!=2){
                    h.hit=true; crashes++; speed*=.55f; score=Math.max(0,score-300); haptic.pulse();
                } else if(dx<2.6f && !h.hit){
                    nearMisses++; score+=75; h.hit=true;
                }
            }
        }
        if(distance>=RUN_LENGTH){
            distance=RUN_LENGTH;
            finished=true;
            score += Math.max(0,4000-crashes*700);
            haptic.pulse();
        }
    }

    private void drawWorld(Canvas c){
        int w=getWidth(), h=getHeight();
        float horizon=h*.29f;

        // Sky
        LinearGradient sky=new LinearGradient(0,0,0,horizon,Color.rgb(18,35,51),Color.rgb(83,116,139),Shader.TileMode.CLAMP);
        p.setShader(sky); c.drawRect(0,0,w,horizon,p); p.setShader(null);

        // Distant Mount Shasta silhouette
        Path m=new Path();
        m.moveTo(0,horizon+30);
        m.lineTo(w*.12f,horizon-5);
        m.lineTo(w*.25f,horizon-28);
        m.lineTo(w*.37f,horizon-55);
        m.lineTo(w*.46f,horizon-115);
        m.lineTo(w*.50f,horizon-155);
        m.lineTo(w*.54f,horizon-118);
        m.lineTo(w*.61f,horizon-62);
        m.lineTo(w*.73f,horizon-30);
        m.lineTo(w*.88f,horizon-5);
        m.lineTo(w,horizon+25);
        m.close();
        p.setColor(Color.rgb(223,231,234)); c.drawPath(m,p);
        p.setColor(Color.argb(100,70,89,98));
        c.drawLine(w*.5f,horizon-152,w*.40f,horizon-55,p);
        c.drawLine(w*.5f,horizon-152,w*.60f,horizon-64,p);

        // Snowfield
        LinearGradient snow=new LinearGradient(0,horizon,0,h,Color.rgb(220,232,236),Color.rgb(245,249,250),Shader.TileMode.CLAMP);
        p.setShader(snow); c.drawRect(0,horizon,w,h,p); p.setShader(null);

        // Perspective slope bands
        for(int i=1;i<9;i++){
            float t=i/9f;
            float y=horizon+(h-horizon)*t*t;
            p.setColor(Color.argb(42,80,125,145));
            c.drawRect(0,y,w,y+2,p);
        }

        // Route walls / ridges
        Path left=new Path(),right=new Path();
        left.moveTo(w*.44f,horizon); right.moveTo(w*.56f,horizon);
        left.lineTo(0,h); right.lineTo(w,h);
        stroke.setStrokeWidth(3); stroke.setColor(Color.argb(110,74,116,132));
        c.drawPath(left,stroke); c.drawPath(right,stroke);

        // Hazards back-to-front
        for(int i=hazards.size()-1;i>=0;i--){
            Hazard hz=hazards.get(i);
            float rel=hz.z-distance;
            if(rel<0 || rel>VIEW_DIST) continue;
            drawHazard(c,hz,rel,horizon,w,h);
        }

        drawPlayer(c,w,h);
        drawHud(c,w,h);
        drawButtons(c,w,h);

        if(!calibrated){
            p.setColor(Color.argb(210,7,19,29));
            c.drawRoundRect(w*.29f,h*.34f,w*.71f,h*.61f,26,26,p);
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Color.WHITE); p.setTextSize(h*.052f);
            c.drawText("HOLD PHONE NEUTRAL",w*.5f,h*.43f,p);
            p.setTextSize(h*.030f); p.setColor(Color.rgb(120,220,239));
            c.drawText("Calibrating motion controls…",w*.5f,h*.49f,p);
            p.setTextSize(h*.023f); p.setColor(Color.LTGRAY);
            c.drawText("Tilt to carve • lean to control speed • flick to jump",w*.5f,h*.55f,p);
        }
        if(finished){
            p.setColor(Color.argb(220,5,14,22)); c.drawRect(0,0,w,h,p);
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Color.WHITE);p.setTextSize(h*.082f);
            c.drawText("BASE REACHED",w*.5f,h*.34f,p);
            p.setTextSize(h*.040f);p.setColor(Color.rgb(185,129,255));
            c.drawText(String.format(Locale.US,"Score %,d   •   Crashes %d   •   Near misses %d",score,crashes,nearMisses),w*.5f,h*.44f,p);
            p.setTextSize(h*.030f);p.setColor(Color.WHITE);
            c.drawText("Tap CAMERA RESET to run again",w*.5f,h*.52f,p);
        }
    }

    private void drawHazard(Canvas c,Hazard hz,float rel,float horizon,int w,int h){
        float t=1f-rel/VIEW_DIST;
        float y=horizon+(h-horizon)*t*t;
        float halfW=70+(w*.62f-70)*t;
        float sx=w*.5f+(hz.x-playerX)*(halfW/11f);
        float s=8+(150f-8f)*t*t;
        if(hz.type==0) drawTree(c,sx,y,s);
        else if(hz.type==1) drawRock(c,sx,y,s*.75f);
        else if(hz.type==2) drawIce(c,sx,y,s*1.2f);
        else if(hz.type==3) drawCrevasse(c,sx,y,s*1.35f);
        else if(hz.type==4) drawBear(c,sx,y,s*.95f);
        else if(hz.type==5) drawCougar(c,sx,y,s*.85f);
        else drawYeti(c,sx,y,s*1.15f);
    }

    private void drawTree(Canvas c,float x,float y,float s){
        p.setColor(Color.rgb(72,58,46));c.drawRect(x-s*.08f,y-s*.10f,x+s*.08f,y+s*.35f,p);
        p.setColor(Color.rgb(21,66,63));
        for(int i=0;i<3;i++){
            Path q=new Path();
            float yy=y-s*.05f-i*s*.18f;
            q.moveTo(x,yy-s*.48f);q.lineTo(x-s*(.34f-i*.03f),yy+s*.20f);q.lineTo(x+s*(.34f-i*.03f),yy+s*.20f);q.close();
            c.drawPath(q,p);
        }
        p.setColor(Color.WHITE); c.drawCircle(x-s*.14f,y-s*.33f,s*.05f,p);
    }
    private void drawRock(Canvas c,float x,float y,float s){
        p.setColor(Color.rgb(75,86,91));
        Path q=new Path();q.moveTo(x-s*.5f,y+s*.25f);q.lineTo(x-s*.25f,y-s*.32f);q.lineTo(x+s*.25f,y-s*.42f);q.lineTo(x+s*.55f,y+s*.24f);q.close();c.drawPath(q,p);
        p.setColor(Color.rgb(210,225,231));c.drawOval(x-s*.28f,y-s*.35f,x+s*.25f,y-s*.12f,p);
    }
    private void drawIce(Canvas c,float x,float y,float s){
        p.setColor(Color.argb(150,57,181,219));
        Path q=new Path();q.moveTo(x-s*.75f,y+s*.12f);q.lineTo(x-s*.28f,y-s*.18f);q.lineTo(x+s*.72f,y-s*.08f);q.lineTo(x+s*.52f,y+s*.20f);q.close();c.drawPath(q,p);
        stroke.setColor(Color.argb(210,210,250,255));stroke.setStrokeWidth(Math.max(2,s*.02f));c.drawLine(x-s*.35f,y-s*.05f,x+s*.35f,y+s*.05f,stroke);
    }
    private void drawCrevasse(Canvas c,float x,float y,float s){
        p.setColor(Color.rgb(17,50,73));
        Path q=new Path();q.moveTo(x-s*.8f,y-s*.08f);q.lineTo(x-s*.18f,y-s*.25f);q.lineTo(x+s*.75f,y-s*.08f);q.lineTo(x+s*.45f,y+s*.20f);q.lineTo(x-s*.65f,y+s*.18f);q.close();c.drawPath(q,p);
        stroke.setColor(Color.rgb(95,210,245));stroke.setStrokeWidth(Math.max(2,s*.025f));c.drawLine(x-s*.65f,y-s*.06f,x+s*.55f,y-s*.02f,stroke);
    }
    private void drawBear(Canvas c,float x,float y,float s){
        p.setColor(Color.rgb(75,49,34));
        c.drawOval(x-s*.48f,y-s*.18f,x+s*.42f,y+s*.28f,p);
        c.drawCircle(x+s*.40f,y-s*.06f,s*.22f,p);
        c.drawCircle(x+s*.30f,y-s*.20f,s*.07f,p);c.drawCircle(x+s*.50f,y-s*.20f,s*.07f,p);
        p.setColor(Color.rgb(20,16,14));c.drawCircle(x+s*.55f,y-s*.03f,s*.035f,p);
    }
    private void drawCougar(Canvas c,float x,float y,float s){
        p.setColor(Color.rgb(171,124,70));
        c.drawOval(x-s*.52f,y-s*.14f,x+s*.40f,y+s*.18f,p);
        c.drawCircle(x+s*.48f,y-s*.08f,s*.16f,p);
        stroke.setColor(Color.rgb(171,124,70));stroke.setStrokeWidth(s*.10f);
        c.drawArc(x-s*.78f,y-s*.25f,x-s*.25f,y+s*.15f,130,180,false,stroke);
    }
    private void drawYeti(Canvas c,float x,float y,float s){
        p.setColor(Color.rgb(225,232,235));
        c.drawOval(x-s*.32f,y-s*.52f,x+s*.34f,y+s*.34f,p);
        c.drawCircle(x,y-s*.58f,s*.25f,p);
        stroke.setStrokeWidth(s*.18f);stroke.setColor(Color.rgb(225,232,235));
        c.drawLine(x-s*.25f,y-s*.25f,x-s*.55f,y+s*.05f,stroke);
        c.drawLine(x+s*.25f,y-s*.25f,x+s*.55f,y+s*.05f,stroke);
        p.setColor(Color.rgb(34,47,54));c.drawCircle(x-s*.07f,y-s*.62f,s*.025f,p);c.drawCircle(x+s*.07f,y-s*.62f,s*.025f,p);
    }

    private void drawPlayer(Canvas c,int w,int h){
        float x=w*.5f;
        float base=h*.84f-jumpY*(h*.055f);
        c.save();
        c.rotate(-steer*10f,x,base);

        // shadow
        p.setColor(Color.argb((int)(90*(1f-Math.min(1,jumpY/3f))),20,34,40));
        c.drawOval(x-w*.055f,h*.875f,x+w*.055f,h*.90f,p);

        // snowboard
        p.setColor(Color.rgb(28,29,35));
        RectF board=new RectF(x-w*.065f,base+h*.055f,x+w*.065f,base+h*.075f);
        c.drawRoundRect(board,20,20,p);
        p.setColor(Color.rgb(116,48,191)); c.drawRect(x-w*.042f,base+h*.058f,x-w*.010f,base+h*.072f,p);
        p.setColor(Color.rgb(36,174,206)); c.drawRect(x+w*.006f,base+h*.058f,x+w*.032f,base+h*.072f,p);
        p.setColor(Color.rgb(232,143,35)); c.drawRect(x+w*.035f,base+h*.058f,x+w*.053f,base+h*.072f,p);

        // legs / cargo pants
        p.setColor(Color.rgb(71,77,65));
        c.drawRoundRect(x-w*.025f,base+h*.010f,x-w*.002f,base+h*.060f,10,10,p);
        c.drawRoundRect(x+w*.005f,base+h*.010f,x+w*.029f,base+h*.060f,10,10,p);

        // boots
        p.setColor(Color.rgb(85,44,128));
        c.drawRoundRect(x-w*.032f,base+h*.048f,x+w*.001f,base+h*.065f,8,8,p);
        c.drawRoundRect(x+w*.001f,base+h*.048f,x+w*.036f,base+h*.065f,8,8,p);

        // puffer jacket
        p.setColor(Color.rgb(20,24,30));
        c.drawRoundRect(x-w*.041f,base-h*.050f,x+w*.042f,base+h*.025f,18,18,p);
        // graffiti color marks
        stroke.setStrokeWidth(Math.max(3,w*.004f));
        stroke.setColor(Color.rgb(119,57,185));c.drawLine(x-w*.033f,base-h*.015f,x-w*.010f,base-h*.036f,stroke);
        stroke.setColor(Color.rgb(39,175,204));c.drawLine(x+w*.004f,base+h*.006f,x+w*.030f,base-h*.018f,stroke);
        stroke.setColor(Color.rgb(221,114,38));c.drawLine(x-w*.030f,base+h*.010f,x-w*.005f,base-h*.008f,stroke);

        // arms
        stroke.setStrokeWidth(w*.018f);stroke.setColor(Color.rgb(20,24,30));
        c.drawLine(x-w*.035f,base-h*.020f,x-w*.058f,base+h*.018f,stroke);
        c.drawLine(x+w*.036f,base-h*.020f,x+w*.061f,base+h*.016f,stroke);

        // head
        p.setColor(Color.rgb(126,78,52)); c.drawCircle(x,base-h*.078f,w*.018f,p);
        // cap
        p.setColor(Color.rgb(15,18,23)); c.drawArc(x-w*.023f,base-h*.104f,x+w*.022f,base-h*.070f,180,180,true,p);
        p.setColor(Color.rgb(115,26,38));c.drawRect(x+w*.012f,base-h*.087f,x+w*.035f,base-h*.081f,p);
        // gold chain
        stroke.setStrokeWidth(w*.003f);stroke.setColor(Color.rgb(215,164,52));
        c.drawArc(x-w*.017f,base-h*.052f,x+w*.017f,base-h*.018f,0,180,false,stroke);

        c.restore();
    }

    private void drawHud(Canvas c,int w,int h){
        p.setTextAlign(Paint.Align.LEFT);
        p.setColor(Color.argb(165,4,15,23));
        c.drawRoundRect(w*.018f,h*.022f,w*.27f,h*.155f,18,18,p);
        p.setColor(Color.WHITE);p.setTextSize(h*.037f);
        c.drawText("FROST LINE: SHASTA",w*.032f,h*.063f,p);
        p.setTextSize(h*.026f);p.setColor(Color.rgb(170,213,230));
        c.drawText(String.format(Locale.US,"%02.0f km/h",speed*3.6f),w*.032f,h*.102f,p);
        c.drawText(String.format(Locale.US,"%04.0f / %.0f m",distance,RUN_LENGTH),w*.13f,h*.102f,p);
        p.setTextSize(h*.021f);p.setColor(Color.LTGRAY);
        c.drawText("SURVIVAL RUN  •  MT SHASTA DEMO",w*.032f,h*.137f,p);

        // progress
        p.setColor(Color.argb(150,0,0,0));c.drawRoundRect(w*.31f,h*.036f,w*.69f,h*.054f,10,10,p);
        p.setColor(Color.rgb(122,56,209));float end=w*.31f+(w*.38f)*(distance/RUN_LENGTH);
        c.drawRoundRect(w*.31f,h*.036f,end,h*.054f,10,10,p);

        p.setTextAlign(Paint.Align.RIGHT);
        p.setColor(Color.WHITE);p.setTextSize(h*.027f);
        c.drawText(String.format(Locale.US,"SCORE %,d",score),w*.975f,h*.06f,p);
        p.setTextSize(h*.021f);p.setColor(Color.LTGRAY);
        c.drawText("CRASHES "+crashes+"   •   NEAR MISS "+nearMisses,w*.975f,h*.095f,p);

        if(grindFlash>0){
            p.setTextAlign(Paint.Align.CENTER);p.setTextSize(h*.045f);p.setColor(Color.rgb(195,131,255));
            c.drawText("GRIND READY",w*.5f,h*.20f,p);
        }
    }

    private void drawButtons(Canvas c,int w,int h){
        float bw=w*.105f,bh=h*.092f,gap=w*.012f,y=h*.865f;
        jumpBtn.set(w-gap-bw,y,w-gap,y+bh);
        grindBtn.set(w-gap*2-bw*2,y,w-gap*2-bw,y+bh);
        resetBtn.set(gap,y,gap+bw*1.25f,y+bh);

        button(c,jumpBtn,"JUMP",Color.rgb(122,56,209));
        button(c,grindBtn,"GRIND",Color.rgb(28,119,147));
        button(c,resetBtn,"CAM RESET",Color.rgb(48,57,64));
    }
    private void button(Canvas c,RectF r,String text,int color){
        p.setColor(Color.argb(205,Color.red(color),Color.green(color),Color.blue(color)));
        c.drawRoundRect(r,18,18,p);
        p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(getHeight()*.025f);
        c.drawText(text,r.centerX(),r.centerY()+getHeight()*.009f,p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            float x=e.getX(),y=e.getY();
            if(jumpBtn.contains(x,y)){ jump(); return true; }
            if(grindBtn.contains(x,y)){ grindFlash=.75f; score+=40; haptic.pulse(); return true; }
            if(resetBtn.contains(x,y)){
                if(finished) restart(); else calibrate();
                return true;
            }
        }
        return true;
    }
}
